const portfolioBtn = document.querySelector('.portfolio-btn');
const portfolioContent = document.querySelector('.header-nav__portfolio-content');

const hello = () => {
    portfolioContent.style.display = 'block';
}

portfolioBtn.addEventListener('mouseover', hello);